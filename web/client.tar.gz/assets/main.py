import sys
import json
import asyncio
import pygame

# --- JSONBIN EINSTELLUNGEN ---
BIN_ID = "6a7b6794da38895dfed6f73c"

is_browser = sys.platform in ("emscripten", "wasi")

player_x, player_y = 400, 300
player2_x, player2_y = 0, 0
player_speed = 5
player_size = 30
player2_adress = ""
running = True

screen_width, screen_height = 800, 600
pygame.display.init()
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()


# --- BROWSER-NETZWERK EMPFÄNGER ---
def browser_on_message(event):
    global player2_x, player2_y, player2_adress
    try:
        # event.data kommt aus JavaScript, wir machen einen Python-String daraus
        msg = str(event.data)
        if msg.count(",") == 2:
            parts = msg.split(",")
            player2_adress = parts[0].strip()
            player2_x = int(parts[1].strip())
            player2_y = int(parts[2].strip())
    except:
        pass


async def main():
    await asyncio.sleep(0)  # <-- NEU: Gibt dem Browser Zeit, den Klick zu registrieren!

    global player_x, player_y, player2_x, player2_y, player2_adress, running

    print("[INFO] Suche aktiven Server über Matchmaker...")
    HOST_DOMAIN = None

    # 1. SERVER-URL ABRUFEN
    if is_browser:
        # BROWSER-MODUS: Nutzt die native JavaScript Fetch-API
        import platform
        window = platform.window
        try:
            url = f"https://api.jsonbin.io/v3/b/{BIN_ID}/latest"
            resp = await window.fetch(url)
            js_data = await resp.json()
            # Sicher von JS-Objekt in ein Python-Dictionary umwandeln
            js_string = window.JSON.stringify(js_data)
            py_data = json.loads(js_string)
            HOST_DOMAIN = py_data['record']['host']
        except Exception as e:
            print(f"[FEHLER] JS Fetch: {e}")
    else:
        # PC-MODUS: Nutzt normales Python
        import requests
        try:
            url = f"https://api.jsonbin.io/v3/b/{BIN_ID}/latest"
            res = requests.get(url).json()
            HOST_DOMAIN = res['record']['host']
        except Exception as e:
            print(f"[FEHLER] Requests Fetch: {e}")

    if not HOST_DOMAIN:
        print("[FEHLER] Kein Server gefunden. Beende...")
        return

    ws_url = f"wss://{HOST_DOMAIN}"
    print(f"[INFO] Verbinde mit Server ({ws_url})...")

    # 2. WEBSOCKET VERBINDUNG AUFBAUEN
    ws_local = None
    browser_ws = None
    adress = "Player1"  # Fallback-Name

    if is_browser:
        # JavaScript WebSocket direkt im Browser aufrufen
        browser_ws = window.WebSocket.new(ws_url)
        browser_ws.onmessage = browser_on_message
        await asyncio.sleep(1)  # Kurz warten, bis JS den Socket öffnet
    else:
        # Python WebSocket für den lokalen PC-Test
        import websockets
        ws_local = await websockets.connect(ws_url)
        adress = await ws_local.recv()

        async def receive_messages():
            global player2_x, player2_y, player2_adress
            try:
                async for message in ws_local:
                    if message and message.count(",") == 2:
                        parts = message.split(",")
                        player2_adress = parts[0].strip()
                        player2_x = int(parts[1].strip())
                        player2_y = int(parts[2].strip())
            except:
                pass

        asyncio.create_task(receive_messages())

    print("[INFO] Spiel startet!")

    # 3. GEMEINSAME SPIEL-SCHLEIFE
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: player_x -= player_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: player_x += player_speed
        if keys[pygame.K_UP] or keys[pygame.K_w]: player_y -= player_speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: player_y += player_speed

        if player_x < 0: player_x = 0
        if player_x > screen_width - player_size: player_x = screen_width - player_size
        if player_y < 0: player_y = 0
        if player_y > screen_height - player_size: player_y = screen_height - player_size

        werte = f"{adress}, {player_x}, {player_y}"

        # Positionsdaten senden
        if is_browser:
            if browser_ws and browser_ws.readyState == 1:  # 1 bedeutet der JS-WebSocket ist OPEN
                browser_ws.send(str(werte))
        else:
            try:
                await ws_local.send(werte)
            except:
                break

        # Alles zeichnen
        screen.fill((30, 40, 60))
        pygame.draw.rect(screen, (230, 50, 50), (player_x, player_y, player_size, player_size))

        pygame.draw.rect(screen, (45, 60, 90), (600, 0, 200, 150))
        pygame.draw.rect(screen, (230, 50, 50), (600 + int(player2_x / 4), int(player2_y / 4), 12.5, 12.5))

        pygame.display.flip()
        clock.tick(60)

        # In Pygbag ist sleep(0) wichtig, um dem Browser das Rendern zu erlauben!
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())